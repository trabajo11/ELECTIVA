document.getElementById('loginForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const errorMsg = document.getElementById('error-msg');

  // Validación simple de ejemplo
  if (username === 'admin' && password === '1234') {
    window.location.href = 'dashboard.html';
  } else {
    errorMsg.textContent = 'Usuario o contraseña incorrectos.';
  }
});
