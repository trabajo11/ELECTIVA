<?php
include '../db.php';

$clientes = $conn->query("SELECT * FROM clientes");
$productos = $conn->query("SELECT * FROM productos WHERE stock > 0");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $cliente_id = $_POST['cliente_id'];
  $dispositivo = $_POST['dispositivo'];
  $problema = $_POST['problema'];
  $estado = $_POST['estado'];

  $stmt = $conn->prepare("INSERT INTO reparaciones (cliente_id, dispositivo, problema, estado) VALUES (?, ?, ?, ?)");
  $stmt->bind_param("isss", $cliente_id, $dispositivo, $problema, $estado);
  $stmt->execute();

  $reparacion_id = $conn->insert_id;

  if (!empty($_POST['productos'])) {
    foreach ($_POST['productos'] as $producto_id) {
      $cantidad = intval($_POST['cantidades'][$producto_id]);
      if ($cantidad > 0) {
        $stmt = $conn->prepare("INSERT INTO reparacion_productos (reparacion_id, producto_id, cantidad) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $reparacion_id, $producto_id, $cantidad);
        $stmt->execute();

        $conn->query("UPDATE productos SET stock = stock - $cantidad WHERE id = $producto_id");
      }
    }
  }

  header("Location: ../dashboard.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Agregar Reparación</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-4">
  <h3>Agregar Reparación</h3>
  <form method="POST">
    <select name="cliente_id" class="form-control mb-3" required>
      <option value="">Seleccione cliente</option>
      <?php while($c = $clientes->fetch_assoc()): ?>
        <option value="<?= $c['id'] ?>"><?= $c['nombre'] ?></option>
      <?php endwhile; ?>
    </select>

    <input type="text" name="dispositivo" class="form-control mb-3" placeholder="Dispositivo" required>
    <textarea name="problema" class="form-control mb-3" placeholder="Problema reportado" required></textarea>

    <select name="estado" class="form-control mb-3" required>
      <option value="Pendiente">Pendiente</option>
      <option value="En proceso">En proceso</option>
      <option value="Completado">Completado</option>
    </select>

    <h5>Productos usados:</h5>
    <?php $productos->data_seek(0); while($p = $productos->fetch_assoc()): ?>
      <div class="form-check mb-2">
        <input class="form-check-input" type="checkbox" name="productos[]" value="<?= $p['id'] ?>" id="prod<?= $p['id'] ?>">
        <label class="form-check-label" for="prod<?= $p['id'] ?>">
          <?= $p['nombre'] ?> (Stock: <?= $p['stock'] ?>)
        </label>
        <input type="number" name="cantidades[<?= $p['id'] ?>]" class="form-control mt-1" placeholder="Cantidad" min="1" style="max-width: 120px;">
      </div>
    <?php endwhile; ?>

    <button class="btn btn-success mt-3">Guardar Reparación</button>
    <a href="../dashboard.php" class="btn btn-secondary mt-3">Cancelar</a>
  </form>
</body>
</html>
