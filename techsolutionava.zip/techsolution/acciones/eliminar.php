<?php
include '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conn->query("DELETE FROM reparaciones WHERE id = $id");
}

header("Location: ../dashboard.php");
exit;
