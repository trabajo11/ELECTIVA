<?php
include '../db.php';

if (!isset($_GET['id'])) header("Location: ../dashboard.php");

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cliente = $_POST['cliente'];
    $dispositivo = $_POST['dispositivo'];
    $problema = $_POST['problema'];
    $estado = $_POST['estado'];

    $stmt = $conn->prepare("UPDATE reparaciones SET cliente=?, dispositivo=?, problema=?, estado=? WHERE id=?");
    $stmt->bind_param("ssssi", $cliente, $dispositivo, $problema, $estado, $id);
    $stmt->execute();

    header("Location: ../dashboard.php");
    exit;
}

$res = $conn->query("SELECT * FROM reparaciones WHERE id=$id");
$data = $res->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Reparación</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
  <h2>Editar Reparación</h2>
  <form method="POST">
    <input type="text" name="cliente" class="form-control mb-3" value="<?= $data['cliente'] ?>" required>
    <input type="text" name="dispositivo" class="form-control mb-3" value="<?= $data['dispositivo'] ?>" required>
    <textarea name="problema" class="form-control mb-3" required><?= $data['problema'] ?></textarea>
    <select name="estado" class="form-control mb-3" required>
      <option <?= $data['estado']=='Pendiente' ? 'selected' : '' ?>>Pendiente</option>
      <option <?= $data['estado']=='En proceso' ? 'selected' : '' ?>>En proceso</option>
      <option <?= $data['estado']=='Completado' ? 'selected' : '' ?>>Completado</option>
    </select>
    <button class="btn btn-primary">Actualizar</button>
    <a href="../dashboard.php" class="btn btn-secondary">Cancelar</a>
  </form>
</body>
</html>
