<?php
// Configuración de cabeceras
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Configuración de la base de datos
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'techsolution';

// Conexión a la base de datos
$conexion = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Verificar conexión
if ($conexion->connect_error) {
    die(json_encode([
        'error' => true,
        'mensaje' => 'Error de conexión a la base de datos: ' . $conexion->connect_error
    ]));
}

// Establecer charset
$conexion->set_charset("utf8");

// Obtener datos del POST
$ticket = isset($_POST['ticket']) ? trim($_POST['ticket']) : '';
$telefono = isset($_POST['telefono']) ? trim($_POST['telefono']) : '';
$nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';

// Preparar la consulta
$query = "SELECT 
            r.id,
            COALESCE(c.nombre, r.cliente) as cliente,
            r.dispositivo,
            r.marca,
            r.modelo,
            r.nombre_usuario,
            r.estado,
            r.fecha_registro,
            r.fecha_finalizacion,
            c.telefono
          FROM reparaciones r
          LEFT JOIN clientes c ON r.cliente_id = c.id
          WHERE 1=0";

$params = [];
$types = "";

// Agregar condiciones según los parámetros recibidos
if (!empty($ticket)) {
    $ticket = str_replace('TS-', '', $ticket);
    $query .= " OR r.id = ?";
    $params[] = $ticket;
    $types .= "i";
}

if (!empty($telefono)) {
    $query .= " OR c.telefono = ?";
    $params[] = $telefono;
    $types .= "s";
}

if (!empty($nombre)) {
    $query .= " OR LOWER(COALESCE(c.nombre, r.cliente)) LIKE LOWER(?)";
    $params[] = "%$nombre%";
    $types .= "s";
}

$query .= " ORDER BY r.fecha_registro DESC LIMIT 1";

// Preparar y ejecutar la consulta
$stmt = $conexion->prepare($query);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows > 0) {
    $reparacion = $resultado->fetch_assoc();
    
    // Calcular fecha estimada (3 días después del registro)
    $fecha_estimada = date('d/m/Y', strtotime($reparacion['fecha_registro'] . ' +3 days'));
    
    // Formatear el número de ticket
    $ticket_formateado = 'TS-' . str_pad($reparacion['id'], 4, '0', STR_PAD_LEFT);
    
    echo json_encode([
        'error' => false,
        'datos' => [
            'ticket' => $ticket_formateado,
            'cliente' => $reparacion['cliente'],
            'dispositivo' => $reparacion['dispositivo'] . ' ' . $reparacion['marca'] . ' ' . $reparacion['modelo'],
            'usuario' => $reparacion['nombre_usuario'],
            'estado' => $reparacion['estado'],
            'fecha_estimada' => $fecha_estimada
        ]
    ]);
} else {
    echo json_encode([
        'error' => true,
        'mensaje' => 'No se encontró ninguna reparación con los datos proporcionados.'
    ]);
}

// Cerrar la conexión
$stmt->close();
$conexion->close();
?>