<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PublicRepairStatusController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Auth\LoginController; // Asumiendo que usarás el sistema de auth de Laravel
use App\Http\Controllers\RepairController;
// ... otros controladores

// Ruta para la consulta pública de estado de reparación
Route::get('/', [PublicRepairStatusController::class, 'showForm'])->name('public.repair.status.form');
Route::post('/consulta-estado', [PublicRepairStatusController::class, 'checkStatus'])->name('public.repair.status.check');

// Rutas de Autenticación (Laravel UI o Breeze las genera)
// Auth::routes(); // Si usas Laravel UI

// Ejemplo para el login si lo haces manualmente o con Breeze/Jetstream
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');


// Rutas protegidas por autenticación
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Rutas para Reparaciones (CRUD)
    Route::resource('reparaciones', RepairController::class); // Esto crea rutas para index, create, store, show, edit, update, destroy

    // Ejemplo de ruta para usar tu procedimiento de búsqueda
    Route::get('/reparaciones/buscar', [RepairController::class, 'search'])->name('reparaciones.buscar');


    // ... Aquí irían las rutas para Clientes, Productos, Usuarios, Configuración, etc.
    // Ejemplo: Route::resource('clientes', ClientController::class);
    // Ejemplo: Route::resource('productos', ProductController::class);
});