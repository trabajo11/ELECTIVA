<?php
session_start();
include 'db.php';

$ip = $_SERVER['REMOTE_ADDR'];
$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = md5($_POST['password']);

  // Verifica IP bloqueada
  $check = $conn->prepare("SELECT ip FROM ip_bloqueadas WHERE ip = ?");
  $check->bind_param("s", $ip);
  $check->execute();
  if ($check->get_result()->num_rows > 0) {
    die("<h3 style='text-align:center;'>🚫 Esta IP está bloqueada</h3>");
  }

  $stmt = $conn->prepare("SELECT * FROM usuarios WHERE username = ? AND password = ?");
  $stmt->bind_param("ss", $username, $password);
  $stmt->execute();
  $res = $stmt->get_result();
  $success = ($res->num_rows === 1);

  // Loguear intento
  $log = $conn->prepare("INSERT INTO intentos_login (ip, username, exito) VALUES (?, ?, ?)");
  $log->bind_param("ssi", $ip, $username, $success);
  $log->execute();

  if ($success) {
    $user = $res->fetch_assoc();
    $_SESSION['usuario'] = $user['username'];
    $_SESSION['rol'] = $user['rol'];
    echo "<script>
      document.addEventListener('DOMContentLoaded', () => {
        const btn = document.getElementById('loginBtn');
        btn.innerHTML = '<i class=\"fas fa-check-circle\"></i> ¡Acceso permitido!';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-success');
        setTimeout(() => {
          window.location.href = 'dashboard.php';
        }, 1500);
      });
    </script>";
  } else {
    $fallos = $conn->query("SELECT COUNT(*) as total FROM intentos_login WHERE ip = '$ip' AND exito = 0 AND fecha >= NOW() - INTERVAL 10 MINUTE")->fetch_assoc()['total'];
    if ($fallos >= 5) {
      $conn->query("INSERT IGNORE INTO ip_bloqueadas (ip) VALUES ('$ip')");
      die("<h3>🚫 IP bloqueada por múltiples intentos</h3>");
    }
    $error = "❌ Usuario o contraseña incorrectos.";
  }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Login - Tech Solution Reparaciones</title>
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/a2e0f1f5fd.js" crossorigin="anonymous"></script>
  <style>
    body {
      background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Roboto', sans-serif;
    }
    .login-card {
      background: rgba(255, 255, 255, 0.95);
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 420px;
      animation: slideIn 0.5s ease-out;
      position: relative;
      overflow: hidden;
    }
    .login-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 5px;
      background: linear-gradient(90deg, #007bff, #00ff88);
    }
    .login-card img.logo {
      width: 120px;
      height: auto;
      margin-bottom: 15px;
      filter: drop-shadow(0 4px 6px rgba(0,0,0,0.1));
    }
    .brand-name {
      color: #2a5298;
      font-weight: 600;
      margin-bottom: 25px;
    }
    .form-floating .form-control:focus {
      border-color: #2a5298;
      box-shadow: 0 0 0 0.25rem rgba(42, 82, 152, 0.25);
    }
    .btn-primary {
      background: #2a5298;
      border: none;
      padding: 12px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    .btn-primary:hover {
      background: #1e3c72;
      transform: translateY(-2px);
    }
    .services-icons {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid #eee;
    }
    .service-item {
      text-align: center;
      color: #666;
      font-size: 0.8rem;
    }
    .service-item i {
      font-size: 1.5rem;
      color: #2a5298;
      margin-bottom: 5px;
    }
    @keyframes slideIn {
      from { transform: translateY(30px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
  </style>
</head>
<body>

  <div class="login-card">
    <div class="text-center mb-4">
      <img src="img/images.jpg" alt="Tech Solution Logo" class="logo">
      <h3 class="brand-name">Tech Solution</h3>
      <p class="text-muted">Centro Especializado en Reparaciones</p>
    </div>

    <form method="POST" id="loginForm">
      <div class="form-floating mb-3">
        <input type="text" class="form-control" name="username" id="username" placeholder="Usuario" required>
        <label for="username"><i class="fas fa-user me-2"></i>Usuario</label>
      </div>

      <div class="form-floating mb-3 position-relative">
        <input type="password" class="form-control" name="password" id="password" placeholder="Contraseña" required>
        <label for="password"><i class="fas fa-lock me-2"></i>Contraseña</label>
        <span class="position-absolute top-50 end-0 translate-middle-y pe-3" style="cursor:pointer;" onclick="togglePassword()">
          <i class="fas fa-eye" id="eye"></i>
        </span>
      </div>

      <div class="form-check mb-3">
        <input class="form-check-input" type="checkbox" id="remember">
        <label class="form-check-label" for="remember">Recordarme</label>
      </div>

      <button id="loginBtn" type="submit" class="btn btn-primary w-100">
        <i class="fas fa-sign-in-alt me-2"></i> Iniciar Sesión
      </button>

      <?php if ($error): ?>
        <div class="alert alert-danger mt-3 animate__animated animate__shakeX"><?= $error ?></div>
      <?php endif; ?>

      <div class="services-icons">
        <div class="service-item">
          <i class="fas fa-laptop"></i>
          <div>Computadoras</div>
        </div>
        <div class="service-item">
          <i class="fas fa-mobile-alt"></i>
          <div>Celulares</div>
        </div>
        <div class="service-item">
          <i class="fas fa-tools"></i>
          <div>Reparaciones</div>
        </div>
        <div class="service-item">
          <i class="fas fa-headset"></i>
          <div>Soporte</div>
        </div>
      </div>
    </form>
  </div>

  <script>
    function togglePassword() {
      const pass = document.getElementById("password");
      const eye = document.getElementById("eye");
      if (pass.type === "password") {
        pass.type = "text";
        eye.classList.remove("fa-eye");
        eye.classList.add("fa-eye-slash");
      } else {
        pass.type = "password";
        eye.classList.remove("fa-eye-slash");
        eye.classList.add("fa-eye");
      }
    }
  </script>
</body>
</html>
