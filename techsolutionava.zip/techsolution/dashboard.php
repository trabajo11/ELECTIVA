<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}
include 'db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];
$nombre = $_SESSION['nombre'] ?? $usuario;

// Estadísticas mejoradas
$stats = $conn->query("
    SELECT 
        (SELECT COUNT(*) FROM reparaciones) as total,
        (SELECT COUNT(*) FROM reparaciones WHERE estado='Pendiente') as pendientes,
        (SELECT COUNT(*) FROM reparaciones WHERE estado='En proceso') as en_proceso,
        (SELECT COUNT(*) FROM reparaciones WHERE estado='Completado') as completadas,
        (SELECT COUNT(*) FROM clientes WHERE activo = 1) as total_clientes,
        (SELECT COUNT(*) FROM productos WHERE stock <= stock_minimo) as stock_bajo
")->fetch_assoc();

// Reparaciones recientes con más detalles
$ultimas = $conn->query("
    SELECT r.id, r.dispositivo, r.marca, r.estado, r.prioridad, 
           r.fecha_registro, c.nombre AS cliente_nombre, c.telefono,
           u.nombre as tecnico_nombre
    FROM reparaciones r
    LEFT JOIN clientes c ON r.cliente_id = c.id
    LEFT JOIN usuarios u ON r.tecnico_asignado = u.id
    ORDER BY r.fecha_registro DESC
    LIMIT 8
");

// Productos con bajo stock
$productos_bajo_stock = $conn->query("
    SELECT nombre, stock, stock_minimo 
    FROM productos 
    WHERE stock <= stock_minimo AND activo = 1
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - TechSolution</title>
  
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Font Awesome 6 -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
  <!-- ApexCharts (Gráficos avanzados) -->
  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
  
  <style>
    :root {
      --primary: #4361ee;
      --secondary: #3f37c9;
      --dark: #212529;
      --light: #f8f9fa;
      --danger: #e63946;
      --warning: #ffc107;
      --info: #17a2b8;
      --success: #28a745;
    }
    
    body {
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      background-color: #f5f7fa;
    }
    
    .sidebar {
      width: 260px;
      background: white;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
      position: fixed;
      height: 100vh;
      transition: all 0.3s;
      overflow-y: auto;
    }
    
    .sidebar-brand {
      padding: 1.5rem;
      background: linear-gradient(to right, var(--primary), var(--secondary));
      color: white;
    }

    .sidebar-section {
      padding: 1rem 0;
      border-bottom: 1px solid rgba(0,0,0,0.05);
    }

    .sidebar-section-title {
      padding: 0.5rem 1.5rem;
      font-size: 0.75rem;
      text-transform: uppercase;
      color: #6c757d;
      font-weight: 600;
      letter-spacing: 0.5px;
    }
    
    .sidebar-link {
      padding: 0.75rem 1.5rem;
      color: #495057;
      border-left: 3px solid transparent;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      text-decoration: none;
    }
    
    .sidebar-link:hover, .sidebar-link.active {
      background-color: rgba(67, 97, 238, 0.1);
      color: var(--primary);
      border-left-color: var(--primary);
      text-decoration: none;
    }
    
    .sidebar-link i {
      width: 24px;
      text-align: center;
      margin-right: 10px;
      font-size: 1.1rem;
    }

    .sidebar-link .badge {
      margin-left: auto;
      font-size: 0.7rem;
      padding: 0.35rem 0.5rem;
    }
    
    .main-content {
      margin-left: 260px;
      padding: 30px;
      min-height: 100vh;
    }
    
    .card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      transition: transform 0.3s, box-shadow 0.3s;
      margin-bottom: 24px;
    }
    
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    
    .card-header {
      background-color: white;
      border-bottom: 1px solid rgba(0,0,0,0.05);
      font-weight: 600;
      padding: 15px 20px;
      border-radius: 10px 10px 0 0 !important;
    }
    
    .stat-card {
      text-align: center;
      padding: 20px;
    }
    
    .stat-card i {
      font-size: 2rem;
      margin-bottom: 15px;
    }
    
    .stat-card .count {
      font-size: 2rem;
      font-weight: 700;
      line-height: 1.2;
    }
    
    .stat-card .label {
      color: #6c757d;
      font-size: 0.9rem;
    }
    
    .badge-priority {
      padding: 5px 8px;
      font-weight: 600;
      font-size: 0.7rem;
      text-transform: uppercase;
    }
    
    .badge-priority.Baja {
      background-color: #d4edda;
      color: #155724;
    }
    
    .badge-priority.Media {
      background-color: #fff3cd;
      color: #856404;
    }
    
    .badge-priority.Alta {
      background-color: #f8d7da;
      color: #721c24;
    }
    
    .badge-priority.Urgente {
      background-color: #721c24;
      color: white;
    }
    
    .badge-status {
      padding: 5px 8px;
      font-weight: 500;
      font-size: 0.75rem;
    }
    
    .badge-status.Pendiente {
      background-color: #fff3cd;
      color: #856404;
    }
    
    .badge-status[class*="En proceso"] {
      background-color: #cce5ff;
      color: #004085;
    }
    
    .badge-status.Completado {
      background-color: #d4edda;
      color: #155724;
    }
    
    .badge-status[class*="Esperando repuesto"] {
      background-color: #e2e3e5;
      color: #383d41;
    }
    
    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background-color: var(--primary);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
    }
    
    .notification-badge {
      position: absolute;
      top: -5px;
      right: -5px;
      font-size: 0.7rem;
    }
    
    @media (max-width: 992px) {
      .sidebar {
        margin-left: -260px;
      }
      .sidebar.active {
        margin-left: 0;
      }
      .main-content {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <div class="sidebar-brand d-flex justify-content-between align-items-center">
      <div>
        <h5 class="mb-0"><i class="fas fa-tools"></i> TechSolution</h5>
        <small class="text-white-50">Panel de Control</small>
      </div>
      <button class="btn btn-sm btn-outline-light d-lg-none" id="sidebarToggle">
        <i class="fas fa-bars"></i>
      </button>
    </div>
    
    <!-- Principal -->
    <div class="sidebar-section">
      <div class="sidebar-section-title">Principal</div>
      <a href="dashboard.php" class="sidebar-link active">
        <i class="fas fa-home"></i> Dashboard
        <?php if($stats['pendientes'] > 0): ?>
        <span class="badge bg-warning rounded-pill"><?= $stats['pendientes'] ?></span>
        <?php endif; ?>
      </a>
      <a href="reparaciones/lista.php" class="sidebar-link">
        <i class="fas fa-wrench"></i> Reparaciones
      </a>
      <a href="reparaciones/nueva.php" class="sidebar-link">
        <i class="fas fa-plus-circle"></i> Nueva Reparación
      </a>
    </div>

    <!-- Gestión -->
    <div class="sidebar-section">
      <div class="sidebar-section-title">Gestión</div>
      <a href="clientes/lista.php" class="sidebar-link">
        <i class="fas fa-users"></i> Clientes
        <?php if($stats['total_clientes'] > 0): ?>
        <span class="badge bg-info rounded-pill"><?= $stats['total_clientes'] ?></span>
        <?php endif; ?>
      </a>
      <a href="productos/inventario.php" class="sidebar-link">
        <i class="fas fa-boxes"></i> Inventario
        <?php if($stats['stock_bajo'] > 0): ?>
        <span class="badge bg-danger rounded-pill"><?= $stats['stock_bajo'] ?></span>
        <?php endif; ?>
      </a>
      <a href="tecnicos/lista.php" class="sidebar-link">
        <i class="fas fa-user-cog"></i> Técnicos
      </a>
    </div>
    
    <?php if ($rol === 'admin'): ?>
    <!-- Administración -->
    <div class="sidebar-section">
      <div class="sidebar-section-title">Administración</div>
      <a href="admin/usuarios/lista.php" class="sidebar-link">
        <i class="fas fa-user-shield"></i> Usuarios
      </a>
      <a href="admin/configuracion/general.php" class="sidebar-link">
        <i class="fas fa-cog"></i> Configuración
      </a>
      <a href="admin/seguridad/bloqueos.php" class="sidebar-link">
        <i class="fas fa-unlock"></i> Seguridad
      </a>
    </div>
    <?php endif; ?>
    
    <!-- Usuario -->
    <div class="sidebar-section">
      <div class="sidebar-section-title">Usuario</div>
      <a href="usuario/perfil.php" class="sidebar-link">
        <i class="fas fa-user"></i> Mi Perfil
      </a>
      <a href="logout.php" class="sidebar-link text-danger">
        <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
      </a>
    </div>
    
    <div class="px-3 py-2 position-absolute bottom-0 w-100 bg-light border-top">
      <div class="d-flex align-items-center">
        <div class="user-avatar me-2">
          <?= strtoupper(substr($nombre, 0, 1)) ?>
        </div>
        <div>
          <div class="fw-bold"><?= $nombre ?></div>
          <small class="text-muted"><?= ucfirst($rol) ?></small>
        </div>
      </div>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="mb-0">Dashboard</h2>
      <div class="d-flex">
        <div class="input-group me-3" style="width: 250px;">
          <input type="text" class="form-control" id="searchInput" placeholder="Buscar reparación...">
          <button class="btn btn-primary" type="button" id="searchBtn">
            <i class="fas fa-search"></i>
          </button>
        </div>
        <div class="position-relative me-3">
          <button class="btn btn-light position-relative" id="notificationsBtn">
            <i class="fas fa-bell"></i>
            <?php
            // Obtener conteo real de notificaciones
            $notificaciones = $conn->query("
                SELECT COUNT(*) as total 
                FROM reparaciones 
                WHERE estado = 'Pendiente' 
                AND fecha_registro >= NOW() - INTERVAL 24 HOUR
            ")->fetch_assoc();
            if ($notificaciones['total'] > 0):
            ?>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge">
              <?= $notificaciones['total'] ?>
            </span>
            <?php endif; ?>
          </button>
        </div>
        <button class="btn btn-light d-lg-none" id="mobileSidebarToggle">
          <i class="fas fa-bars"></i>
        </button>
      </div>
    </div>
    
    <!-- Welcome Card -->
    <div class="card bg-gradient-primary text-white mb-4">
      <div class="card-body">
        <div class="row align-items-center">
          <div class="col-md-8">
            <h3 class="mb-3">Bienvenido, <?= $nombre ?></h3>
            <p class="mb-4">Aquí tienes un resumen de las actividades recientes en tu taller.</p>
            <a href="reparaciones/nueva.php" class="btn btn-light">
              <i class="fas fa-plus-circle me-2"></i> Nueva Reparación
            </a>
          </div>
          <div class="col-md-4 text-center d-none d-md-block">
            <img src="assets/img/dashboard-welcome.png" style="height: 150px;" alt="Ilustración">
          </div>
        </div>
      </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="row">
      <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-start border-primary border-4">
          <div class="card-body">
            <i class="fas fa-wrench text-primary mb-3"></i>
            <h3 class="count"><?= $stats['total'] ?></h3>
            <p class="label">Reparaciones Totales</p>
          </div>
        </div>
      </div>
      
      <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-start border-warning border-4">
          <div class="card-body">
            <i class="fas fa-clock text-warning mb-3"></i>
            <h3 class="count"><?= $stats['pendientes'] ?></h3>
            <p class="label">Pendientes</p>
          </div>
        </div>
      </div>
      
      <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-start border-info border-4">
          <div class="card-body">
            <i class="fas fa-cogs text-info mb-3"></i>
            <h3 class="count"><?= $stats['en_proceso'] ?></h3>
            <p class="label">En Proceso</p>
          </div>
        </div>
      </div>
      
      <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-start border-success border-4">
          <div class="card-body">
            <i class="fas fa-check-circle text-success mb-3"></i>
            <h3 class="count"><?= $stats['completadas'] ?></h3>
            <p class="label">Completadas</p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="row">
      <!-- Gráfico de Reparaciones -->
      <div class="col-lg-8">
        <div class="card">
          <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-chart-line me-2"></i> Estadísticas de Reparaciones</span>
            <select class="form-select form-select-sm" style="width: auto;">
              <option>Últimos 7 días</option>
              <option selected>Últimos 30 días</option>
              <option>Este mes</option>
              <option>Este año</option>
            </select>
          </div>
          <div class="card-body">
            <div id="reparacionesChart" style="height: 300px;"></div>
          </div>
        </div>
      </div>
      
      <!-- Productos con bajo stock -->
      <div class="col-lg-4">
        <div class="card">
          <div class="card-header">
            <i class="fas fa-exclamation-triangle me-2 text-danger"></i> Productos con bajo stock
          </div>
          <div class="card-body">
            <div class="list-group">
              <?php while($p = $productos_bajo_stock->fetch_assoc()): ?>
              <div class="list-group-item border-0 py-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div><?= $p['nombre'] ?></div>
                  <span class="badge bg-danger">
                    <?= $p['stock'] ?> / <?= $p['stock_minimo'] ?>
                  </span>
                </div>
                <div class="progress mt-2" style="height: 5px;">
                  <div class="progress-bar bg-danger" 
                       style="width: <?= ($p['stock'] / $p['stock_minimo']) * 100 ?>%">
                  </div>
                </div>
              </div>
              <?php endwhile; ?>
            </div>
            <a href="productos/inventario.php" class="btn btn-sm btn-outline-primary mt-3 w-100">
              Ver todo el inventario
            </a>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Últimas Reparaciones -->
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-history me-2"></i> Últimas Reparaciones</span>
            <a href="reparaciones/lista.php" class="btn btn-sm btn-primary">
              Ver todas <i class="fas fa-arrow-right ms-1"></i>
            </a>
          </div>
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-hover mb-0">
                <thead class="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Dispositivo</th>
                    <th>Técnico</th>
                    <th>Estado</th>
                    <th>Prioridad</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while($r = $ultimas->fetch_assoc()): ?>
                  <tr>
                    <td>#<?= $r['id'] ?></td>
                    <td>
                      <div class="fw-bold"><?= $r['cliente_nombre'] ?? 'Sin cliente' ?></div>
                      <small class="text-muted"><?= $r['telefono'] ?? '' ?></small>
                    </td>
                    <td>
                      <div class="fw-bold"><?= $r['dispositivo'] ?></div>
                      <small class="text-muted"><?= $r['marca'] ?></small>
                    </td>
                    <td><?= $r['tecnico_nombre'] ?? 'Sin asignar' ?></td>
                    <td>
                      <span class="badge badge-status <?= $r['estado'] ?>">
                        <?= $r['estado'] ?>
                      </span>
                    </td>
                    <td>
                      <span class="badge badge-priority <?= $r['prioridad'] ?>">
                        <?= $r['prioridad'] ?>
                      </span>
                    </td>
                    <td><?= date('d/m/Y', strtotime($r['fecha_registro'])) ?></td>
                    <td>
                      <button class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-eye"></i>
                      </button>
                    </td>
                  </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Admin Section -->
    <?php if ($rol === 'admin'): ?>
    <div class="row mt-4">
      <div class="col-md-6">
        <div class="card">
          <div class="card-header">
            <i class="fas fa-shield-alt me-2"></i> Seguridad - Intentos de acceso
          </div>
          <div class="card-body">
            <div id="securityChart"></div>
            <div class="table-responsive mt-3">
              <table class="table table-sm">
                <thead>
                  <tr>
                    <th>IP</th>
                    <th>Usuario</th>
                    <th>Resultado</th>
                    <th>Fecha</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $logs = $conn->query("
                    SELECT * FROM intentos_login 
                    ORDER BY fecha DESC LIMIT 5
                  ");
                  while ($l = $logs->fetch_assoc()):
                  ?>
                  <tr>
                    <td><?= $l['ip'] ?></td>
                    <td><?= $l['username'] ?: 'N/A' ?></td>
                    <td>
                      <?php if ($l['exito']): ?>
                        <span class="badge bg-success">Éxito</span>
                      <?php else: ?>
                        <span class="badge bg-danger">Fallido</span>
                      <?php endif; ?>
                    </td>
                    <td><?= date('H:i d/m', strtotime($l['fecha'])) ?></td>
                  </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-6">
        <div class="card">
          <div class="card-header">
            <i class="fas fa-lock me-2"></i> IPs Bloqueadas
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-sm">
                <thead>
                  <tr>
                    <th>IP</th>
                    <th>Razón</th>
                    <th>Fecha</th>
                    <th>Acción</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $blocked = $conn->query("
                    SELECT * FROM ip_bloqueadas 
                    WHERE activo = 1
                    ORDER BY fecha_bloqueo DESC LIMIT 5
                  ");
                  while ($b = $blocked->fetch_assoc()):
                  ?>
                  <tr>
                    <td><?= $b['ip'] ?></td>
                    <td><?= $b['razon'] ?></td>
                    <td><?= date('d/m/Y', strtotime($b['fecha_bloqueo'])) ?></td>
                    <td>
                      <button class="btn btn-sm btn-outline-success">
                        <i class="fas fa-unlock"></i>
                      </button>
                    </td>
                  </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
            <a href="admin/seguridad/bloqueos.php" class="btn btn-sm btn-primary mt-2">
              Gestionar bloqueos
            </a>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  
  <script>
    // Toggle sidebar en móvil
    document.getElementById('mobileSidebarToggle').addEventListener('click', function() {
        document.querySelector('.sidebar').classList.toggle('active');
        document.querySelector('.main-content').classList.toggle('sidebar-active');
    });

    // Búsqueda en tiempo real
    document.getElementById('searchInput').addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        const rows = document.querySelectorAll('table tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    });

    // Gráfico de reparaciones con datos reales
    var options = {
        series: [{
            name: 'Reparaciones',
            data: [
                <?= $stats['pendientes'] ?>, 
                <?= $stats['en_proceso'] ?>, 
                <?= $stats['completadas'] ?>
            ]
        }],
        chart: {
            type: 'bar',
            height: '100%',
            toolbar: { show: false }
        },
        plotOptions: {
            bar: {
                borderRadius: 4,
                horizontal: false,
                columnWidth: '55%',
            }
        },
        dataLabels: { enabled: false },
        stroke: { show: true, width: 2, colors: ['transparent'] },
        xaxis: {
            categories: ['Pendientes', 'En Proceso', 'Completadas'],
        },
        yaxis: { title: { text: 'Cantidad' } },
        fill: { opacity: 1 },
        colors: ['#ffc107', '#17a2b8', '#28a745'],
        tooltip: {
            y: { formatter: function(val) { return val + " reparaciones" } }
        }
    };

    var chart = new ApexCharts(document.querySelector("#reparacionesChart"), options);
    chart.render();

    <?php if ($rol === 'admin'): ?>
    // Gráfico de seguridad con datos reales
    var securityData = <?php
        $security_stats = $conn->query("
            SELECT 
                DATE_FORMAT(fecha, '%d/%m') as dia,
                COUNT(*) as total
            FROM intentos_login
            WHERE fecha >= NOW() - INTERVAL 7 DAY
            GROUP BY DATE(fecha)
            ORDER BY fecha
        ")->fetch_all(MYSQLI_ASSOC);
        echo json_encode($security_stats);
    ?>;

    var securityOptions = {
        series: [{
            name: 'Accesos',
            data: securityData.map(item => item.total)
        }],
        chart: {
            type: 'line',
            height: 200,
            toolbar: { show: false }
        },
        stroke: { curve: 'smooth', width: 3 },
        colors: ['#4361ee'],
        xaxis: {
            categories: securityData.map(item => item.dia)
        },
        tooltip: { enabled: true }
    };

    var securityChart = new ApexCharts(document.querySelector("#securityChart"), securityOptions);
    securityChart.render();
    <?php endif; ?>

    // Sistema de notificaciones
    document.getElementById('notificationsBtn').addEventListener('click', function() {
        // Aquí se implementaría la lógica para mostrar las notificaciones
        // Por ahora solo mostraremos un mensaje
        alert('Próximamente: Sistema de notificaciones');
    });
  </script>
</body>
</html>