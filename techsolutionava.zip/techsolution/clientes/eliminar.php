<?php
session_start();
require_once "../conexion.php";

if (!isset($_GET['id'])) {
    header('Location: lista.php');
    exit();
}

$id = (int)$_GET['id'];

// Realizar borrado lógico (actualizar campo activo a 0)
$stmt = $conexion->prepare("UPDATE clientes SET activo = 0 WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: lista.php?mensaje=eliminado");
} else {
    header("Location: lista.php?error=1");
}
exit();
?>
