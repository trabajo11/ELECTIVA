<?php
include '../db.php';
$clientes = $conn->query("SELECT * FROM clientes");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Clientes - Tech Solution</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-5">
  <h2>Clientes</h2>
  <a href="agregar.php" class="btn btn-success mb-3">Agregar Cliente</a>
  <a href="../dashboard.php" class="btn btn-secondary mb-3">Volver</a>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Teléfono</th>
        <th>Email</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while($c = $clientes->fetch_assoc()): ?>
        <tr>
          <td><?= $c['nombre'] ?></td>
          <td><?= $c['telefono'] ?></td>
          <td><?= $c['email'] ?></td>
          <td>
            <a href="editar.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-primary">Editar</a>
            <a href="eliminar.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar cliente?')">Eliminar</a>
            <a href="historial.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-info">Historial</a>

          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</body>
</html>
