<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Factura de Reparación - Tech Solution</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .company-info { margin-bottom: 20px; }
        .ticket-info { border: 1px solid #ccc; padding: 10px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .footer { margin-top: 30px; text-align: center; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Tech Solution</h1>
        <h2>Factura de Reparación</h2>
    </div>

    <div class="company-info">
        <h3>Información de la Empresa:</h3>
        <p>Tech Solution - Servicio Técnico Profesional</p>
        <p>Dirección: [Dirección de la empresa]</p>
        <p>Teléfono: [Teléfono de la empresa]</p>
        <p>Email: [Email de la empresa]</p>
        <p>NIF/CIF: [Número fiscal]</p>
    </div>

    <div class="ticket-info">
        <h3>Información del Ticket</h3>
        <p><strong>Número de Ticket:</strong> <?php echo $ticket_numero; ?></p>
        <p><strong>Fecha:</strong> <?php echo date('d/m/Y H:i'); ?></p>
        <p><strong>Cliente:</strong> <?php echo $cliente['nombre']; ?></p>
        <p><strong>Teléfono:</strong> <?php echo $cliente['telefono']; ?></p>
        <p><strong>Email:</strong> <?php echo $cliente['email']; ?></p>
    </div>

    <div class="service-details">
        <h3>Detalles del Servicio</h3>
        <table>
            <tr>
                <th>Producto/Servicio</th>
                <th>Descripción</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Total</th>
            </tr>
            <?php foreach($servicios as $servicio): ?>
            <tr>
                <td><?php echo $servicio['producto']; ?></td>
                <td><?php echo $servicio['descripcion']; ?></td>
                <td><?php echo $servicio['cantidad']; ?></td>
                <td><?php echo number_format($servicio['precio'], 2); ?>€</td>
                <td><?php echo number_format($servicio['cantidad'] * $servicio['precio'], 2); ?>€</td>
            </tr>
            <?php endforeach; ?>
        </table>

        <div style="text-align: right; margin-top: 20px;">
            <p><strong>Subtotal:</strong> <?php echo number_format($subtotal, 2); ?>€</p>
            <p><strong>IVA (21%):</strong> <?php echo number_format($iva, 2); ?>€</p>
            <p><strong>Total:</strong> <?php echo number_format($total, 2); ?>€</p>
        </div>
    </div>

    <div class="footer">
        <p><strong>Observaciones:</strong></p>
        <p><?php echo $observaciones; ?></p>
        <p>Gracias por confiar en Tech Solution</p>
        <p>Para cualquier consulta, por favor indique su número de ticket: <?php echo $ticket_numero; ?></p>
    </div>
</body>
</html>

