<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; // Para Stored Procedures

class DashboardController extends Controller
{
    public function index()
    {
        // Llama al procedimiento almacenado obtener_estadisticas_dashboard
        $stats = DB::select('CALL obtener_estadisticas_dashboard()');
        $estadisticas = $stats[0] ?? null; // El SP devuelve un array con un objeto

        // Tu vista vista_productos_stock_bajo
        $productosBajoStock = DB::table('vista_productos_stock_bajo')->get();

        return view('dashboard', compact('estadisticas', 'productosBajoStock'));
    }
}