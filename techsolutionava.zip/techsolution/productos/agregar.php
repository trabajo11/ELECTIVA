<?php
session_start();
include '../db.php';

// Activar reporte de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validar y limpiar los datos de entrada
        $nombre = trim($_POST['nombre']);
        $descripcion = trim($_POST['descripcion'] ?? '');
        $precio_venta = floatval($_POST['precio_venta']);
        $precio_compra = floatval($_POST['precio_compra']);
        $stock = intval($_POST['stock']);
        $categoria = trim($_POST['categoria'] ?? '');
        $stock_minimo = intval($_POST['stock_minimo']);

        // Validaciones básicas
        if (empty($nombre)) {
            throw new Exception("El nombre del producto es obligatorio");
        }

        if ($precio_venta < 0 || $precio_compra < 0) {
            throw new Exception("Los precios no pueden ser negativos");
        }

        if ($stock < 0 || $stock_minimo < 0) {
            throw new Exception("El stock no puede ser negativo");
        }

        // Imprimir los valores para debug
        error_log("Datos a insertar:");
        error_log("Nombre: " . $nombre);
        error_log("Descripción: " . $descripcion);
        error_log("Precio Venta: " . $precio_venta);
        error_log("Precio Compra: " . $precio_compra);
        error_log("Stock: " . $stock);
        error_log("Categoría: " . $categoria);
        error_log("Stock Mínimo: " . $stock_minimo);

        // Preparar la consulta
        $query = "INSERT INTO productos (
            nombre, descripcion, precio_venta, precio_compra, 
            stock, categoria, stock_minimo, activo
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 1)";

        error_log("Query a ejecutar: " . $query);

        $stmt = $conn->prepare($query);
        
        if (!$stmt) {
            throw new Exception("Error en la preparación de la consulta: " . $conn->error);
        }

        // Vincular parámetros
        if (!$stmt->bind_param("ssddisi", 
            $nombre, $descripcion, $precio_venta, $precio_compra, 
            $stock, $categoria, $stock_minimo
        )) {
            throw new Exception("Error al vincular parámetros: " . $stmt->error);
        }

        // Ejecutar la consulta
        if (!$stmt->execute()) {
            throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
        }

        $_SESSION['success'] = "Producto agregado correctamente.";
        header("Location: listar.php");
        exit;

    } catch (Exception $e) {
        error_log("Error en agregar.php: " . $e->getMessage());
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
}

// Mostrar el último error de MySQL si existe
if ($conn->error) {
    error_log("Último error de MySQL: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h3>Agregar Nuevo Producto</h3>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?= htmlspecialchars($_SESSION['error']) ?>
                    <?php unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?= htmlspecialchars($_SESSION['success']) ?>
                    <?php unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>

            <form method="POST" novalidate>
                <div class="mb-3">
                    <label for="nombre" class="form-label">Nombre del producto *</label>
                    <input type="text" name="nombre" id="nombre" class="form-control" 
                           value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label for="descripcion" class="form-label">Descripción</label>
                    <textarea name="descripcion" id="descripcion" class="form-control" rows="3"
                    ><?= htmlspecialchars($_POST['descripcion'] ?? '') ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="categoria" class="form-label">Categoría</label>
                    <input type="text" name="categoria" id="categoria" class="form-control"
                           value="<?= htmlspecialchars($_POST['categoria'] ?? '') ?>">
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="precio_venta" class="form-label">Precio de Venta *</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" name="precio_venta" id="precio_venta" 
                                       class="form-control" step="0.01" min="0" 
                                       value="<?= htmlspecialchars($_POST['precio_venta'] ?? '') ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="precio_compra" class="form-label">Precio de Compra *</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" name="precio_compra" id="precio_compra" 
                                       class="form-control" step="0.01" min="0" 
                                       value="<?= htmlspecialchars($_POST['precio_compra'] ?? '') ?>" required>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="stock" class="form-label">Stock inicial *</label>
                            <input type="number" name="stock" id="stock" class="form-control" 
                                   min="0" value="<?= htmlspecialchars($_POST['stock'] ?? '0') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="stock_minimo" class="form-label">Stock mínimo</label>
                            <input type="number" name="stock_minimo" id="stock_minimo" 
                                   class="form-control" min="0" 
                                   value="<?= htmlspecialchars($_POST['stock_minimo'] ?? '5') ?>">
                        </div>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-success">Guardar Producto</button>
                    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
