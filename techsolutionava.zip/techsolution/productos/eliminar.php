<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
include '../db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

if (!isset($_GET['id'])) {
    header("Location: inventario.php");
    exit;
}

$id = (int)$_GET['id'];

// Verificar que el producto existe
$stmt = $conn->prepare("SELECT id FROM productos WHERE id = ? AND activo = 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result->fetch_assoc()) {
    $_SESSION['error'] = "El producto no existe o ya está inactivo.";
    header("Location: inventario.php");
    exit;
}

// Realizar baja lógica
$stmt = $conn->prepare("UPDATE productos SET activo = 0 WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    // Registrar la eliminación
    $conn->query("
        INSERT INTO log_productos (
            producto_id, accion, usuario, fecha
        ) VALUES (
            $id, 'Eliminación', 
            '" . $conn->real_escape_string($usuario) . "',
            NOW()
        )
    ");
    
    $_SESSION['success'] = "Producto eliminado correctamente.";
} else {
    $_SESSION['error'] = "Error al eliminar el producto.";
}

header("Location: inventario.php");
exit;
?>
