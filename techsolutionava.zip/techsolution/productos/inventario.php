<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
include '../db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

// Consulta de productos con estadísticas
$query = "
    SELECT p.*,
           CASE 
               WHEN p.stock <= p.stock_minimo THEN 'bajo'
               WHEN p.stock <= p.stock_minimo * 1.5 THEN 'medio'
               ELSE 'normal'
           END as nivel_stock
    FROM productos p
    WHERE p.activo = 1
    ORDER BY p.nombre ASC";

$productos = $conn->query($query);

// Estadísticas generales
$stats = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN stock <= stock_minimo THEN 1 ELSE 0 END) as bajo_stock,
        SUM(precio_venta * stock) as valor_total
    FROM productos 
    WHERE activo = 1
")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario - TechSolution</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container-fluid py-4">
        <!-- Header con estadísticas -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="text-muted">Total de Productos</h6>
                        <h3><?= $stats['total'] ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="text-muted">Productos con Bajo Stock</h6>
                        <h3 class="text-warning"><?= $stats['bajo_stock'] ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="text-muted">Valor Total del Inventario</h6>
                        <h3>$<?= number_format($stats['valor_total'], 2) ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Inventario</h2>
            <div>
                <button class="btn btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#importarModal">
                    <i class="fas fa-file-import me-2"></i>Importar
                </button>
                <a href="nuevo.php" class="btn btn-primary">
                    <i class="fas fa-plus-circle me-2"></i>Nuevo Producto
                </a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Producto</th>
                                <th>Categoría</th>
                                <th>Stock</th>
                                <th>Precio</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($p = $productos->fetch_assoc()): ?>
                            <tr>
                                <td>#<?= $p['id'] ?></td>
                                <td>
                                    <div class="fw-bold"><?= $p['nombre'] ?></div>
                                    <?php if ($p['descripcion']): ?>
                                    <small class="text-muted"><?= $p['descripcion'] ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-secondary">
                                        <?= $p['categoria'] ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <span class="badge bg-<?= getStockColor($p['nivel_stock']) ?> me-2">
                                            <?= $p['stock'] ?>
                                        </span>
                                        <small class="text-muted">
                                            Min: <?= $p['stock_minimo'] ?>
                                        </small>
                                    </div>
                                </td>
                                <td>$<?= number_format($p['precio_venta'], 2) ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-info" 
                                                onclick="ajustarStock(<?= $p['id'] ?>, '<?= $p['nombre'] ?>')">
                                            <i class="fas fa-boxes"></i>
                                        </button>
                                        <a href="editar.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger" 
                                                onclick="confirmarEliminacion(<?= $p['id'] ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Ajustar Stock -->
    <div class="modal fade" id="ajustarStockModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Ajustar Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="ajustar_stock.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="producto_id" id="producto_id">
                        <div class="mb-3">
                            <label class="form-label">Producto</label>
                            <input type="text" class="form-control" id="producto_nombre" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="cantidad" class="form-label">Cantidad</label>
                            <input type="number" class="form-control" name="cantidad" required>
                            <div class="form-text">
                                Use números negativos para restar stock.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="motivo" class="form-label">Motivo</label>
                            <select class="form-select" name="motivo" required>
                                <option value="Compra">Compra</option>
                                <option value="Venta">Venta</option>
                                <option value="Ajuste">Ajuste de inventario</option>
                                <option value="Merma">Merma</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="comentario" class="form-label">Comentario</label>
                            <textarea class="form-control" name="comentario" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Importar -->
    <div class="modal fade" id="importarModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Importar Productos</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="importar.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="archivo" class="form-label">Archivo CSV</label>
                            <input type="file" class="form-control" name="archivo" accept=".csv" required>
                        </div>
                        <div class="alert alert-info">
                            <h6 class="alert-heading">Formato del archivo:</h6>
                            <p class="mb-0">
                                nombre,descripcion,categoria,stock,stock_minimo,precio
                            </p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Importar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function ajustarStock(id, nombre) {
        document.getElementById('producto_id').value = id;
        document.getElementById('producto_nombre').value = nombre;
        new bootstrap.Modal(document.getElementById('ajustarStockModal')).show();
    }

    function confirmarEliminacion(id) {
        if (confirm('¿Estás seguro de que deseas eliminar este producto?')) {
            window.location.href = `eliminar.php?id=${id}`;
        }
    }
    </script>
</body>
</html>

<?php
function getStockColor($nivel) {
    switch($nivel) {
        case 'bajo': return 'danger';
        case 'medio': return 'warning';
        default: return 'success';
    }
}
?> 