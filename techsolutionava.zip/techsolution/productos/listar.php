<?php
session_start();
if (!isset($_SESSION['usuario'])) header("Location: ../login.php");
include '../db.php';
$productos = $conn->query("SELECT * FROM productos ORDER BY nombre ASC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Inventario - Productos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
  <h3>📦 Productos en Inventario</h3>
  <a href="agregar.php" class="btn btn-success mb-3">+ Agregar Producto</a>
  <a href="../dashboard.php" class="btn btn-secondary mb-3">Volver</a>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Descripción</th>
        <th>Precio Venta ($)</th>
        <th>Precio Compra ($)</th>
        <th>Stock</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while($p = $productos->fetch_assoc()): ?>
        <tr>
          <td><?= $p['nombre'] ?></td>
          <td><?= $p['descripcion'] ?></td>
          <td><?= number_format($p['precio_venta'], 2) ?></td>
          <td><?= number_format($p['precio_compra'], 2) ?></td>
          <td><?= $p['stock'] ?></td>
          <td>
            <a href="editar.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-primary">Editar</a>
            <a href="eliminar.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar producto?')">Eliminar</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</body>
</html>
