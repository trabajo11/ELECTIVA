<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
include '../db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: inventario.php");
    exit;
}

$producto_id = (int)$_POST['producto_id'];
$cantidad = (int)$_POST['cantidad'];
$motivo = $_POST['motivo'];
$comentario = $_POST['comentario'];

// Verificar que el producto existe
$stmt = $conn->prepare("SELECT stock FROM productos WHERE id = ? AND activo = 1");
$stmt->bind_param("i", $producto_id);
$stmt->execute();
$result = $stmt->get_result();
$producto = $result->fetch_assoc();

if (!$producto) {
    $_SESSION['error'] = "El producto no existe o está inactivo.";
    header("Location: inventario.php");
    exit;
}

// Verificar que el nuevo stock no sea negativo
$nuevo_stock = $producto['stock'] + $cantidad;
if ($nuevo_stock < 0) {
    $_SESSION['error'] = "No hay suficiente stock para realizar esta operación.";
    header("Location: inventario.php");
    exit;
}

// Iniciar transacción
$conn->begin_transaction();

try {
    // Actualizar stock
    $stmt = $conn->prepare("
        UPDATE productos 
        SET stock = stock + ?, 
            ultimo_movimiento = NOW()
        WHERE id = ?
    ");
    $stmt->bind_param("ii", $cantidad, $producto_id);
    $stmt->execute();

    // Registrar movimiento
    $stmt = $conn->prepare("
        INSERT INTO movimientos_stock (
            producto_id, cantidad, motivo, comentario, 
            usuario, fecha, stock_anterior, stock_nuevo
        ) VALUES (?, ?, ?, ?, ?, NOW(), ?, ?)
    ");
    $stmt->bind_param(
        "iisssii",
        $producto_id, $cantidad, $motivo, $comentario,
        $usuario, $producto['stock'], $nuevo_stock
    );
    $stmt->execute();

    $conn->commit();
    $_SESSION['success'] = "Stock actualizado correctamente.";
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error'] = "Error al actualizar el stock: " . $e->getMessage();
}

header("Location: inventario.php");
exit;
?> 