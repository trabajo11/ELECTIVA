<?php
include '../db.php';
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nombre = $_POST['nombre'];
  $descripcion = $_POST['descripcion'];
  $precio_venta = $_POST['precio_venta'];
  $precio_compra = $_POST['precio_compra'];
  $stock = $_POST['stock'];

  $stmt = $conn->prepare("UPDATE productos SET nombre=?, descripcion=?, precio_venta=?, precio_compra=?, stock=? WHERE id=?");
  $stmt->bind_param("ssddii", $nombre, $descripcion, $precio_venta, $precio_compra, $stock, $id);
  $stmt->execute();

  header("Location: listar.php");
}

$producto = $conn->query("SELECT * FROM productos WHERE id=$id")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Producto</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
  <h3>Editar Producto</h3>
  <form method="POST">
    <div class="mb-3">
      <label for="nombre" class="form-label">Nombre</label>
      <input type="text" name="nombre" id="nombre" class="form-control" value="<?= $producto['nombre'] ?>" required>
    </div>
    
    <div class="mb-3">
      <label for="descripcion" class="form-label">Descripción</label>
      <textarea name="descripcion" id="descripcion" class="form-control" required><?= $producto['descripcion'] ?></textarea>
    </div>
    
    <div class="mb-3">
      <label for="precio_venta" class="form-label">Precio de Venta</label>
      <input type="number" name="precio_venta" id="precio_venta" class="form-control" step="0.01" value="<?= $producto['precio_venta'] ?>" required>
    </div>

    <div class="mb-3">
      <label for="precio_compra" class="form-label">Precio de Compra</label>
      <input type="number" name="precio_compra" id="precio_compra" class="form-control" step="0.01" value="<?= $producto['precio_compra'] ?>" required>
    </div>
    
    <div class="mb-3">
      <label for="stock" class="form-label">Stock</label>
      <input type="number" name="stock" id="stock" class="form-control" value="<?= $producto['stock'] ?>" required>
    </div>

    <button type="submit" class="btn btn-primary">Actualizar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
  </form>
</body>
</html>
