<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
include '../db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['archivo'])) {
    header("Location: inventario.php");
    exit;
}

$archivo = $_FILES['archivo'];
$errores = [];
$importados = 0;

// Verificar el archivo
if ($archivo['error'] !== UPLOAD_ERR_OK) {
    $_SESSION['error'] = "Error al subir el archivo.";
    header("Location: inventario.php");
    exit;
}

if ($archivo['type'] !== 'text/csv') {
    $_SESSION['error'] = "El archivo debe ser CSV.";
    header("Location: inventario.php");
    exit;
}

// Abrir el archivo
$handle = fopen($archivo['tmp_name'], 'r');
if (!$handle) {
    $_SESSION['error'] = "No se pudo abrir el archivo.";
    header("Location: inventario.php");
    exit;
}

// Saltar la primera línea (encabezados)
fgetcsv($handle);

// Iniciar transacción
$conn->begin_transaction();

try {
    // Preparar la consulta
    $stmt = $conn->prepare("
        INSERT INTO productos (
            nombre, descripcion, categoria, stock, 
            stock_minimo, precio, activo, fecha_registro
        ) VALUES (?, ?, ?, ?, ?, ?, 1, NOW())
    ");

    // Procesar cada línea
    while (($data = fgetcsv($handle)) !== FALSE) {
        // Verificar el número de columnas
        if (count($data) < 6) {
            $errores[] = "Línea inválida: faltan campos";
            continue;
        }

        // Asignar valores
        $nombre = trim($data[0]);
        $descripcion = trim($data[1]);
        $categoria = trim($data[2]);
        $stock = (int)$data[3];
        $stock_minimo = (int)$data[4];
        $precio = (float)$data[5];

        // Validaciones básicas
        if (empty($nombre)) {
            $errores[] = "El nombre es obligatorio";
            continue;
        }

        if ($stock < 0 || $stock_minimo < 0 || $precio < 0) {
            $errores[] = "Valores negativos no permitidos para: $nombre";
            continue;
        }

        // Insertar el producto
        $stmt->bind_param(
            "sssiid",
            $nombre, $descripcion, $categoria,
            $stock, $stock_minimo, $precio
        );

        if ($stmt->execute()) {
            $importados++;
        } else {
            $errores[] = "Error al importar: $nombre";
        }
    }

    // Si hay errores, hacer rollback
    if (!empty($errores)) {
        $conn->rollback();
        $_SESSION['error'] = "Errores en la importación:\n" . implode("\n", $errores);
    } else {
        $conn->commit();
        $_SESSION['success'] = "Se importaron $importados productos correctamente.";
    }

} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error'] = "Error en la importación: " . $e->getMessage();
}

// Cerrar el archivo
fclose($handle);

header("Location: inventario.php");
exit;
?> 