<?php
$host = 'localhost';
$dbname = 'techsolution';
$username = 'root';
$password = '';

try {
    $conexion = new mysqli($host, $username, $password, $dbname);
    if ($conexion->connect_error) {
        throw new Exception("Error de conexión: " . $conexion->connect_error);
    }
    $conexion->set_charset("utf8");
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?> 