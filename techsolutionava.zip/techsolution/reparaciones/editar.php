<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
include '../db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

if (!isset($_GET['id'])) {
    header("Location: lista.php");
    exit;
}

$id = (int)$_GET['id'];

// Obtener detalles de la reparación
$query = "
    SELECT r.*, c.nombre as cliente_nombre, c.telefono,
           u.nombre as tecnico_nombre
    FROM reparaciones r
    LEFT JOIN clientes c ON r.cliente_id = c.id
    LEFT JOIN usuarios u ON r.tecnico_asignado = u.id
    WHERE r.id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$reparacion = $result->fetch_assoc();

if (!$reparacion) {
    header("Location: lista.php");
    exit;
}

// Obtener lista de técnicos
$tecnicos = $conn->query("SELECT id, nombre FROM usuarios WHERE rol = 'tecnico' AND activo = 1");

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $estado = $_POST['estado'];
    $prioridad = $_POST['prioridad'];
    $tecnico_id = $_POST['tecnico_id'] ?: null;
    $diagnostico = $_POST['diagnostico'];
    $comentario = $_POST['comentario'];
    
    // Actualizar reparación
    $stmt = $conn->prepare("
        UPDATE reparaciones 
        SET estado = ?, prioridad = ?, tecnico_asignado = ?, diagnostico = ?
        WHERE id = ?
    ");
    
    $stmt->bind_param("ssisi", $estado, $prioridad, $tecnico_id, $diagnostico, $id);
    
    if ($stmt->execute()) {
        // Registrar en historial si hay cambio de estado
        if ($estado != $reparacion['estado']) {
            $conn->query("
                INSERT INTO reparacion_historial (
                    reparacion_id, estado_anterior, estado_nuevo, comentario, usuario_id
                ) VALUES (
                    $id, 
                    '" . $reparacion['estado'] . "',
                    '$estado', 
                    '" . $conn->real_escape_string($comentario) . "',
                    (SELECT id FROM usuarios WHERE username = '" . $conn->real_escape_string($usuario) . "')
                )
            ");
        }
        
        header("Location: ver.php?id=$id");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Reparación - TechSolution</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Editar Reparación #<?= $id ?></h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <!-- Información del Cliente (No editable) -->
                            <div class="mb-4">
                                <h5>Cliente</h5>
                                <p class="mb-1">
                                    <strong><?= $reparacion['cliente_nombre'] ?></strong>
                                </p>
                                <?php if ($reparacion['telefono']): ?>
                                <p class="mb-0 text-muted">
                                    <i class="fas fa-phone me-2"></i><?= $reparacion['telefono'] ?>
                                </p>
                                <?php endif; ?>
                            </div>

                            <!-- Información del Dispositivo (No editable) -->
                            <div class="mb-4">
                                <h5>Dispositivo</h5>
                                <p class="mb-1">
                                    <strong><?= $reparacion['dispositivo'] ?></strong>
                                    (<?= $reparacion['marca'] ?> - <?= $reparacion['modelo'] ?>)
                                </p>
                                <p class="mb-0 text-muted">
                                    <?= $reparacion['problema'] ?>
                                </p>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="estado" class="form-label">Estado</label>
                                        <select class="form-select" id="estado" name="estado" required>
                                            <option value="Pendiente" <?= $reparacion['estado'] == 'Pendiente' ? 'selected' : '' ?>>
                                                Pendiente
                                            </option>
                                            <option value="En proceso" <?= $reparacion['estado'] == 'En proceso' ? 'selected' : '' ?>>
                                                En proceso
                                            </option>
                                            <option value="Completado" <?= $reparacion['estado'] == 'Completado' ? 'selected' : '' ?>>
                                                Completado
                                            </option>
                                            <option value="Cancelado" <?= $reparacion['estado'] == 'Cancelado' ? 'selected' : '' ?>>
                                                Cancelado
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="prioridad" class="form-label">Prioridad</label>
                                        <select class="form-select" id="prioridad" name="prioridad" required>
                                            <option value="Baja" <?= $reparacion['prioridad'] == 'Baja' ? 'selected' : '' ?>>
                                                Baja
                                            </option>
                                            <option value="Media" <?= $reparacion['prioridad'] == 'Media' ? 'selected' : '' ?>>
                                                Media
                                            </option>
                                            <option value="Alta" <?= $reparacion['prioridad'] == 'Alta' ? 'selected' : '' ?>>
                                                Alta
                                            </option>
                                            <option value="Urgente" <?= $reparacion['prioridad'] == 'Urgente' ? 'selected' : '' ?>>
                                                Urgente
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="tecnico_id" class="form-label">Técnico</label>
                                        <select class="form-select" id="tecnico_id" name="tecnico_id">
                                            <option value="">Sin asignar</option>
                                            <?php while($t = $tecnicos->fetch_assoc()): ?>
                                            <option value="<?= $t['id'] ?>" 
                                                <?= $reparacion['tecnico_asignado'] == $t['id'] ? 'selected' : '' ?>>
                                                <?= $t['nombre'] ?>
                                            </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="diagnostico" class="form-label">Diagnóstico Técnico</label>
                                <textarea class="form-control" id="diagnostico" name="diagnostico" rows="3"><?= htmlspecialchars($reparacion['diagnostico']) ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="comentario" class="form-label">Comentario del Cambio</label>
                                <textarea class="form-control" id="comentario" name="comentario" rows="2"></textarea>
                                <div class="form-text">
                                    Este comentario se registrará en el historial si hay cambio de estado.
                                </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2">
                                <a href="ver.php?id=<?= $id ?>" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 