<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
include '../db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

// Consulta de reparaciones con información detallada
$query = "
    SELECT r.*, c.nombre as cliente_nombre, c.telefono, u.nombre as tecnico_nombre
    FROM reparaciones r
    LEFT JOIN clientes c ON r.cliente_id = c.id
    LEFT JOIN usuarios u ON r.tecnico_asignado = u.id
    ORDER BY r.fecha_registro DESC";

$reparaciones = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Reparaciones - TechSolution</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Lista de Reparaciones</h2>
            <a href="nueva.php" class="btn btn-primary">
                <i class="fas fa-plus-circle me-2"></i>Nueva Reparación
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Dispositivo</th>
                                <th>Técnico</th>
                                <th>Estado</th>
                                <th>Prioridad</th>
                                <th>Fecha</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($r = $reparaciones->fetch_assoc()): ?>
                            <tr>
                                <td>#<?= $r['id'] ?></td>
                                <td>
                                    <div class="fw-bold"><?= $r['cliente_nombre'] ?? 'Sin cliente' ?></div>
                                    <small class="text-muted"><?= $r['telefono'] ?? '' ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold"><?= $r['dispositivo'] ?></div>
                                    <small class="text-muted"><?= $r['marca'] ?></small>
                                </td>
                                <td><?= $r['tecnico_nombre'] ?? 'Sin asignar' ?></td>
                                <td>
                                    <span class="badge bg-<?= getStatusColor($r['estado']) ?>">
                                        <?= $r['estado'] ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?= getPriorityColor($r['prioridad']) ?>">
                                        <?= $r['prioridad'] ?>
                                    </span>
                                </td>
                                <td><?= date('d/m/Y', strtotime($r['fecha_registro'])) ?></td>
                                <td>
                                    <a href="ver.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="editar.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
function getStatusColor($estado) {
    switch($estado) {
        case 'Pendiente': return 'warning';
        case 'En proceso': return 'info';
        case 'Completado': return 'success';
        case 'Cancelado': return 'danger';
        default: return 'secondary';
    }
}

function getPriorityColor($prioridad) {
    switch($prioridad) {
        case 'Alta': return 'danger';
        case 'Media': return 'warning';
        case 'Baja': return 'success';
        default: return 'secondary';
    }
}
?> 