<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
include '../db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

if (!isset($_GET['id'])) {
    header("Location: lista.php");
    exit;
}

$id = (int)$_GET['id'];

// Obtener detalles de la reparación
$query = "
    SELECT r.*, c.nombre as cliente_nombre, c.telefono, c.email,
           u.nombre as tecnico_nombre
    FROM reparaciones r
    LEFT JOIN clientes c ON r.cliente_id = c.id
    LEFT JOIN usuarios u ON r.tecnico_asignado = u.id
    WHERE r.id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$reparacion = $result->fetch_assoc();

if (!$reparacion) {
    header("Location: lista.php");
    exit;
}

// Obtener historial de estados
$historial = $conn->query("
    SELECT * FROM reparacion_historial 
    WHERE reparacion_id = $id 
    ORDER BY fecha_cambio DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles de Reparación - TechSolution</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Detalles de Reparación #<?= $id ?></h2>
            <div>
                <a href="lista.php" class="btn btn-secondary me-2">
                    <i class="fas fa-arrow-left me-2"></i>Volver
                </a>
                <a href="editar.php?id=<?= $id ?>" class="btn btn-warning">
                    <i class="fas fa-edit me-2"></i>Editar
                </a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <!-- Detalles principales -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Información del Dispositivo</h5>
                                <dl class="row">
                                    <dt class="col-sm-4">Dispositivo</dt>
                                    <dd class="col-sm-8"><?= $reparacion['dispositivo'] ?></dd>
                                    
                                    <dt class="col-sm-4">Marca</dt>
                                    <dd class="col-sm-8"><?= $reparacion['marca'] ?></dd>
                                    
                                    <dt class="col-sm-4">Modelo</dt>
                                    <dd class="col-sm-8"><?= $reparacion['modelo'] ?></dd>
                                </dl>
                            </div>
                            <div class="col-md-6">
                                <h5>Estado Actual</h5>
                                <dl class="row">
                                    <dt class="col-sm-4">Estado</dt>
                                    <dd class="col-sm-8">
                                        <span class="badge bg-<?= getStatusColor($reparacion['estado']) ?>">
                                            <?= $reparacion['estado'] ?>
                                        </span>
                                    </dd>
                                    
                                    <dt class="col-sm-4">Prioridad</dt>
                                    <dd class="col-sm-8">
                                        <span class="badge bg-<?= getPriorityColor($reparacion['prioridad']) ?>">
                                            <?= $reparacion['prioridad'] ?>
                                        </span>
                                    </dd>
                                    
                                    <dt class="col-sm-4">Fecha</dt>
                                    <dd class="col-sm-8">
                                        <?= date('d/m/Y H:i', strtotime($reparacion['fecha_registro'])) ?>
                                    </dd>
                                </dl>
                            </div>
                        </div>

                        <h5>Problema Reportado</h5>
                        <p class="border-start border-4 border-primary ps-3">
                            <?= nl2br(htmlspecialchars($reparacion['problema'])) ?>
                        </p>

                        <?php if ($reparacion['diagnostico']): ?>
                        <h5>Diagnóstico Técnico</h5>
                        <p class="border-start border-4 border-info ps-3">
                            <?= nl2br(htmlspecialchars($reparacion['diagnostico'])) ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Historial -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-history me-2"></i>Historial
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="timeline">
                            <?php while($h = $historial->fetch_assoc()): ?>
                            <div class="timeline-item">
                                <div class="timeline-marker"></div>
                                <div class="timeline-content">
                                    <h6 class="mb-0"><?= $h['estado_nuevo'] ?></h6>
                                    <small class="text-muted">
                                        <?= date('d/m/Y H:i', strtotime($h['fecha_cambio'])) ?>
                                    </small>
                                    <?php if ($h['comentario']): ?>
                                    <p class="mt-2"><?= $h['comentario'] ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Información del Cliente -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-user me-2"></i>Cliente
                        </h5>
                    </div>
                    <div class="card-body">
                        <h6><?= $reparacion['cliente_nombre'] ?></h6>
                        <?php if ($reparacion['telefono']): ?>
                        <p class="mb-1">
                            <i class="fas fa-phone me-2"></i>
                            <?= $reparacion['telefono'] ?>
                        </p>
                        <?php endif; ?>
                        <?php if ($reparacion['email']): ?>
                        <p class="mb-0">
                            <i class="fas fa-envelope me-2"></i>
                            <?= $reparacion['email'] ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Técnico Asignado -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-user-cog me-2"></i>Técnico Asignado
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if ($reparacion['tecnico_nombre']): ?>
                        <h6><?= $reparacion['tecnico_nombre'] ?></h6>
                        <?php else: ?>
                        <p class="text-muted mb-0">Sin técnico asignado</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
function getStatusColor($estado) {
    switch($estado) {
        case 'Pendiente': return 'warning';
        case 'En proceso': return 'info';
        case 'Completado': return 'success';
        case 'Cancelado': return 'danger';
        default: return 'secondary';
    }
}

function getPriorityColor($prioridad) {
    switch($prioridad) {
        case 'Alta': return 'danger';
        case 'Media': return 'warning';
        case 'Baja': return 'success';
        default: return 'secondary';
    }
}
?> 