<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
include '../db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

// Obtener lista de clientes
$clientes = $conn->query("SELECT id, nombre, telefono FROM clientes WHERE activo = 1");

// Obtener lista de técnicos
$tecnicos = $conn->query("SELECT id, nombre FROM usuarios WHERE rol = 'tecnico' AND activo = 1");

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Manejar nuevo cliente si se está registrando uno
    $cliente_id = null;
    if (isset($_POST['es_nuevo_cliente']) && $_POST['es_nuevo_cliente'] == '1') {
        // Insertar nuevo cliente
        $stmt = $conn->prepare("INSERT INTO clientes (nombre, telefono, email, direccion, activo) VALUES (?, ?, ?, ?, 1)");
        $stmt->bind_param("ssss", $_POST['nuevo_cliente_nombre'], $_POST['nuevo_cliente_telefono'], 
                                 $_POST['nuevo_cliente_email'], $_POST['nuevo_cliente_direccion']);
        if ($stmt->execute()) {
            $cliente_id = $stmt->insert_id;
        } else {
            $_SESSION['error'] = "Error al registrar el nuevo cliente";
            header("Location: nueva.php");
            exit;
        }
    } else {
        $cliente_id = $_POST['cliente_id'];
    }

    $dispositivo = $_POST['dispositivo'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $problema = $_POST['problema'];
    $estado = 'Pendiente';
    $prioridad = $_POST['prioridad'];
    $tecnico_id = $_POST['tecnico_id'] ?: null;
    
    $stmt = $conn->prepare("
        INSERT INTO reparaciones (
            cliente_id, dispositivo, marca, modelo, problema, 
            estado, prioridad, tecnico_asignado, fecha_registro
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->bind_param(
        "issssssi",
        $cliente_id, $dispositivo, $marca, $modelo, $problema,
        $estado, $prioridad, $tecnico_id
    );
    
    if ($stmt->execute()) {
        $reparacion_id = $stmt->insert_id;
        $ticket = 'TS-' . str_pad($reparacion_id, 4, '0', STR_PAD_LEFT);
        $_SESSION['mensaje'] = "Reparación registrada exitosamente. El número de ticket es: " . $ticket;
        header("Location: lista.php");
        exit;
    }
}

// Mensajes de éxito o error
$mensaje = '';
$error = '';
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    unset($_SESSION['mensaje']);
}
if (isset($_SESSION['error'])) {
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva Reparación - TechSolution</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-4">
        <?php if ($mensaje): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?= $mensaje ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Nueva Reparación</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <label class="form-label">Cliente</label>
                                    <button type="button" class="btn btn-sm btn-outline-primary" id="toggleClienteForm">
                                        <i class="fas fa-plus"></i> Nuevo Cliente
                                    </button>
                                </div>
                                
                                <!-- Selector de cliente existente -->
                                <div id="clienteExistente">
                                    <select class="form-select" id="cliente_id" name="cliente_id">
                                        <option value="">Seleccionar cliente existente...</option>
                                        <?php while($c = $clientes->fetch_assoc()): ?>
                                        <option value="<?= $c['id'] ?>">
                                            <?= $c['nombre'] ?> - <?= $c['telefono'] ?>
                                        </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>

                                <!-- Formulario para nuevo cliente -->
                                <div id="nuevoClienteForm" style="display: none;">
                                    <input type="hidden" name="es_nuevo_cliente" id="es_nuevo_cliente" value="0">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <input type="text" class="form-control" name="nuevo_cliente_nombre" 
                                                   placeholder="Nombre del cliente">
                                        </div>
                                        <div class="col-md-6">
                                            <input type="tel" class="form-control" name="nuevo_cliente_telefono" 
                                                   placeholder="Teléfono">
                                        </div>
                                        <div class="col-md-6">
                                            <input type="email" class="form-control" name="nuevo_cliente_email" 
                                                   placeholder="Email">
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control" name="nuevo_cliente_direccion" 
                                                   placeholder="Dirección">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="dispositivo" class="form-label">Dispositivo</label>
                                        <input type="text" class="form-control" id="dispositivo" name="dispositivo" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="marca" class="form-label">Marca</label>
                                        <input type="text" class="form-control" id="marca" name="marca" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="modelo" class="form-label">Modelo</label>
                                        <input type="text" class="form-control" id="modelo" name="modelo" required>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="problema" class="form-label">Descripción del Problema</label>
                                <textarea class="form-control" id="problema" name="problema" rows="3" required></textarea>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="prioridad" class="form-label">Prioridad</label>
                                        <select class="form-select" id="prioridad" name="prioridad" required>
                                            <option value="Baja">Baja</option>
                                            <option value="Media" selected>Media</option>
                                            <option value="Alta">Alta</option>
                                            <option value="Urgente">Urgente</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="tecnico_id" class="form-label">Asignar Técnico</label>
                                        <select class="form-select" id="tecnico_id" name="tecnico_id">
                                            <option value="">Sin asignar</option>
                                            <?php while($t = $tecnicos->fetch_assoc()): ?>
                                            <option value="<?= $t['id'] ?>"><?= $t['nombre'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2">
                                <a href="lista.php" class="btn btn-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-primary">Guardar Reparación</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toggleBtn = document.getElementById('toggleClienteForm');
            const clienteExistente = document.getElementById('clienteExistente');
            const nuevoClienteForm = document.getElementById('nuevoClienteForm');
            const clienteSelect = document.getElementById('cliente_id');
            const esNuevoClienteInput = document.getElementById('es_nuevo_cliente');

            toggleBtn.addEventListener('click', function() {
                const isNuevoVisible = nuevoClienteForm.style.display !== 'none';
                
                if (isNuevoVisible) {
                    nuevoClienteForm.style.display = 'none';
                    clienteExistente.style.display = 'block';
                    toggleBtn.innerHTML = '<i class="fas fa-plus"></i> Nuevo Cliente';
                    clienteSelect.required = true;
                    esNuevoClienteInput.value = '0';
                } else {
                    nuevoClienteForm.style.display = 'block';
                    clienteExistente.style.display = 'none';
                    toggleBtn.innerHTML = '<i class="fas fa-list"></i> Seleccionar Cliente Existente';
                    clienteSelect.required = false;
                    esNuevoClienteInput.value = '1';
                }
            });
        });
    </script>
</body>
</html> 